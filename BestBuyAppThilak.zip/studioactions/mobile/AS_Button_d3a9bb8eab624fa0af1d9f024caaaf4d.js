function AS_Button_d3a9bb8eab624fa0af1d9f024caaaf4d(eventobject) {
    return searchMethod.call(this);
}