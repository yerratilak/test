function AS_Button_570cf0088d394736b0f35815ebd219db(eventobject) {
    return cancelMethod.call(this);
}