function AS_Image_da72b6f9c6804f95b3c00da17ce53a79(eventobject, x, y) {
    return onSearchIconClick.call(this);
}