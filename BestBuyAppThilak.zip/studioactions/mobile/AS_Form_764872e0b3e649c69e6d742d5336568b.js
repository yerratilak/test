function AS_Form_764872e0b3e649c69e6d742d5336568b(eventobject) {
    BBTCategories.BBTCflexmain.FlexSearchAnimation.opacity = 0;
    //showloadingindicator();
}