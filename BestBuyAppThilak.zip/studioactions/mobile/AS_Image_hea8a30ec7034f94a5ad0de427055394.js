function AS_Image_hea8a30ec7034f94a5ad0de427055394(eventobject, x, y) {
    BBTProductLIST.show();
    BBTProductDetails.destroy();
}