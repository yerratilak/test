function AS_FlexContainer_c6d8dee1a3b0420894bf7d8f3064aebf(eventobject, x, y) {
    BBTProductLIST.show();
    BBTProductDetails.destroy();
}