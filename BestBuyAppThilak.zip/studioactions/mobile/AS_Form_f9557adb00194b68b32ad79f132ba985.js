function AS_Form_f9557adb00194b68b32ad79f132ba985(eventobject) {
    BBTProductDetails.flexmaster.imgsearch.isVisible = false;
}