function AS_Image_fc97da9067d144a3abb53954a19eb6ad(eventobject, x, y) {
    return searchMethod.call(this);
}