function AS_Image_2486fb90d32945638dd8ccba1326ccf0(eventobject, x, y) {
    return searchMethod.call(this);
}