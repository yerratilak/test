function AS_Image_2ac948da865d410f8c101eb1b60f2247(eventobject, x, y) {
    BBTProductLIST.show();
    BBTProductDetails.destroy();
}