function AS_Image_0de08ed06e9c460eac705aebddd392eb(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}