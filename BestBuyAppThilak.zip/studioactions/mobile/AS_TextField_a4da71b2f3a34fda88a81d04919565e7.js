function AS_TextField_a4da71b2f3a34fda88a81d04919565e7(eventobject, changedtext) {
    var searchtbxval = BBTCategories.searchTbox.text;
    if (searchtbxval == "") {
        BBTCategories.searchBtn.text = "Cancel";
    } else {
        BBTCategories.searchBtn.text = "Search";
    }
}