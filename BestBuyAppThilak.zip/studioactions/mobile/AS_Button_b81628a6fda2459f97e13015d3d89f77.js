function AS_Button_b81628a6fda2459f97e13015d3d89f77(eventobject) {
    return previousaction.call(this);
}