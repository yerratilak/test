function AS_Segment_432858926a6a4bb8ae9342ac1dbaa984(eventobject, sectionNumber, rowNumber) {
    return getCategories.call(this);
}