function AS_Image_aab67dc5a57e4ec58d831336e3e13c9c(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}