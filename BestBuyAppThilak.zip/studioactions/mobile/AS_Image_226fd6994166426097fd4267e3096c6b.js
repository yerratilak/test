function AS_Image_226fd6994166426097fd4267e3096c6b(eventobject, x, y) {
    return searchMethod.call(this);
}