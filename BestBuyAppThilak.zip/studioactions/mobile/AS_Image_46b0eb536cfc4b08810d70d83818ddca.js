function AS_Image_46b0eb536cfc4b08810d70d83818ddca(eventobject, x, y) {
    return searchMethod.call(this);
}