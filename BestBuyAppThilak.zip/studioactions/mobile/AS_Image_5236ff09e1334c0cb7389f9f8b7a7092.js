function AS_Image_5236ff09e1334c0cb7389f9f8b7a7092(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}