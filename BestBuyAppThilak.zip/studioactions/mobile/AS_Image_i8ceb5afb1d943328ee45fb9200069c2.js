function AS_Image_i8ceb5afb1d943328ee45fb9200069c2(eventobject, x, y) {
    BBTProductLIST.show();
    BBTProductDetails.destroy();
}