function AS_Image_60e88d16fee34cf6b6bcecca623c6641(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}