function AS_AppEvents_60245f8331c6445e92e487ad32f6fea3(eventobject) {
    return initsdk.call(this);
}