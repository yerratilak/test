function AS_Image_7759dc6073af4313a6e9fde9bfd1b9ee(eventobject, x, y) {
    return searchMethod.call(this);
}