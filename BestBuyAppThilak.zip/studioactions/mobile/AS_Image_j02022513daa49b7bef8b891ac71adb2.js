function AS_Image_j02022513daa49b7bef8b891ac71adb2(eventobject, x, y) {
    return onSearchIconClick.call(this);
}