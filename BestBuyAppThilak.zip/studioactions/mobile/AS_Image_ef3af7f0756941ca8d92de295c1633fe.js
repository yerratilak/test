function AS_Image_ef3af7f0756941ca8d92de295c1633fe(eventobject, x, y) {
    return searchMethod.call(this);
}