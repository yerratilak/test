function AS_Segment_c797460a794f4fb686a4c82298edcc2a(eventobject, sectionNumber, rowNumber) {
    return getCategories.call(this);
}