function AS_Image_f5be8573c2b747f2a56150aef0e26f3f(eventobject, x, y) {
    BBTProductLIST.show();
    BBTProductDetails.destroy();
}