function AS_Segment_hd41bd8da2974cf6acd8690b15f480f5(eventobject, sectionNumber, rowNumber) {
    return getSelectedProductDetails.call(this);
}