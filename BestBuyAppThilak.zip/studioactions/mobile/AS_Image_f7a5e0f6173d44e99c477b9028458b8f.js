function AS_Image_f7a5e0f6173d44e99c477b9028458b8f(eventobject, x, y) {
    alert("search");
    searchMethod();
}