function AS_TextField_485bcb1f8d424ca28f0ba23596d7d9f3(eventobject, changedtext) {
    var searchtbxval = BBTCategories.searchTbox.text;
    if (searchtbxval == "") {
        BBTCategories.searchBtn.text = "Cancel";
    } else {
        BBTCategories.searchBtn.text = "Search";
    }
}