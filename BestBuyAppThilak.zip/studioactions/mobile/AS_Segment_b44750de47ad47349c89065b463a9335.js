function AS_Segment_b44750de47ad47349c89065b463a9335(eventobject, sectionNumber, rowNumber) {
    return getCategories.call(this);
}