function AS_Image_da82c41b65924461a20418c119496694(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}