function AS_FlexContainer_a1391fb7f1b649ae971ce9ebde109f00(eventobject, x, y) {
    BBTProductLIST.show();
    BBTProductDetails.destroy();
}