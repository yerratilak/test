function AS_Form_2d879320827644939a25ed3d2c8ec703(eventobject) {
    categoriesAnimation();
}