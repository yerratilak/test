function AS_Image_ca08c6af1d0b408593319cb839c15fd0(eventobject, x, y) {
    BBTProductLIST.show();
    BBTProductDetails.destroy();
}