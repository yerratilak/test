function AS_Image_06c12491d4664708bb47b6dab887de4d(eventobject, x, y) {
    return searchMethod.call(this);
}