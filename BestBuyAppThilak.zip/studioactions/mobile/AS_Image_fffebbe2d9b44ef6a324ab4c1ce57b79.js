function AS_Image_fffebbe2d9b44ef6a324ab4c1ce57b79(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}