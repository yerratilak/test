function AS_Image_025232c1cde54f73a24c9b2fa9ab33ed(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}