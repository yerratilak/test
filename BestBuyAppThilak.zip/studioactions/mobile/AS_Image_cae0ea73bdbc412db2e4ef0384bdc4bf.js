function AS_Image_cae0ea73bdbc412db2e4ef0384bdc4bf(eventobject, x, y) {
    return onSearchIconClick.call(this);
}