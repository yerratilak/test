function AS_Image_abf7f4996f614e26992115b02ae130a2(eventobject, x, y) {
    BBTProductLIST.show();
    BBTProductDetails.destroy();
}