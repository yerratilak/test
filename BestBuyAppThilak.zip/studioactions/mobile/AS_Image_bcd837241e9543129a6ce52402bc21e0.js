function AS_Image_bcd837241e9543129a6ce52402bc21e0(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}