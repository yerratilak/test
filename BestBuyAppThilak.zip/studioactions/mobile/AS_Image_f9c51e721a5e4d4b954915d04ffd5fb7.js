function AS_Image_f9c51e721a5e4d4b954915d04ffd5fb7(eventobject, x, y) {
    return gobacknextpage.call(this, null);
}