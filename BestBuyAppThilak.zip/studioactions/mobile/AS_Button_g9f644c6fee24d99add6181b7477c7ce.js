function AS_Button_g9f644c6fee24d99add6181b7477c7ce(eventobject) {
    return cancelMethod.call(this);
}