function AS_Image_7cbfde16261348d8bcc67c1155175e33(eventobject, x, y) {
    return gobacknextpage.call(this, "");
}