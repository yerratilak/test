function AS_Image_bb79e9fb19744b42a8d3324e2dfd290e(eventobject, x, y) {
    return onSearchIconClick.call(this);
}