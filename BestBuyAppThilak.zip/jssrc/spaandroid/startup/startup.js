//startup.js file
var appConfig = {
    appId: "BestBuyAppThilak",
    appName: "BestBuyAppThilak",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.35.107",
    serverPort: "80",
    secureServerPort: "443",
    isturlbase: "http://kh1934.kitspl.com:8080/services",
    isMFApp: true,
    appKey: "fa7234294c02a58690553a37ca8f1caf",
    appSecret: "ed9328f1c46b1c25a042207b32d4bdc6",
    serviceUrl: "http://kh1934.kitspl.com:8080/authService/100000002/appconfig",
    svcDoc: {
        "selflink": "http://kh1934.kitspl.com:8080/authService/100000002/appconfig",
        "service_doc_etag": "00000164D92B4140",
        "appId": "b26a213a-f0ce-46a1-85eb-b44c16230544",
        "identity_features": {
            "reporting_params_header_allowed": true
        },
        "name": "BestBuyAppThilak",
        "reportingsvc": {
            "session": "http://kh1934.kitspl.com:8080/services/IST",
            "custom": "http://kh1934.kitspl.com:8080/services/CMS"
        },
        "baseId": "419ced74-227b-4c7c-ba74-e9b1ded61091",
        "services_meta": {},
        "Webapp": {
            "url": "http://kh1934.kitspl.com:8080/BestBuyAppThilak"
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "Error", "Crash"],
    url: "http://kh1934.kitspl.com:8080/authService/100000002/appconfig",
    secureurl: "http://kh1934.kitspl.com:8080/authService/100000002/appconfig",
    middlewareContext: "BestBuyAppThilak"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    initializeUserWidgets();
    initializeCategoryRowTemplate();
    initializeProductReviewRowTemplate();
    initializeProductsRowTemplate();
    BBTCategoriesGlobals();
    BBTProductDetailsGlobals();
    BBTProductLISTGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        APILevel: 7200
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    requirejs.config({
        baseUrl: "spaandroid/appjs"
    });
    var requireModulesList = getSPARequireModulesList();
    require(requireModulesList, function() {
        kony.application.setApplicationInitializationEvents({
            init: appInit,
            postappinit: AS_AppEvents_60245f8331c6445e92e487ad32f6fea3,
            showstartupform: function() {
                BBTCategories.show();
            }
        });
    });
};

function loadResources() {
    kony.theme.packagedthemes(
        ["default"]);
    globalhttpheaders = {};
    callAppMenu();
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "serviceUrl": appConfig.serviceUrl,
        eventTypes: ["FormEntry", "Error", "Crash"]
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    spaAPM && spaAPM.startTracking();
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}

function initializeApp() {
    kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
    //If default locale is specified. This is set even before any other app life cycle event is called.
    loadResources();
};
									function getSPARequireModulesList(){ return ['kvmodules']; }
								