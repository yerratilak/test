kony.globals["appid"] = "BestBuyAppThilak";
kony.globals["locales"] = [];