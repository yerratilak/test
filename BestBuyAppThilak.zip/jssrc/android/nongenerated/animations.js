//Type your code here
function categoriesAnimation() {
    var transformObject = kony.ui.makeAffineTransform();
    transformObject.translate(270, 0);
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.translate(0, 0);
    animationConfig = {
        duration: 0.5,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    };
    animationDef = {
        0: {
            "transform": transformObject
        },
        100: {
            "transform": transformObject1
        }
    };
    animationDefObject = kony.ui.createAnimation(animationDef);
    BBTCategories.CategorySeg.setAnimations({
        visible: {
            definition: animationDefObject,
            config: animationConfig
        }
    });
}

function ProductListAnimation() {
    var transformObject = kony.ui.makeAffineTransform();
    transformObject.scale(0, 0);
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(1, 1);
    animationConfig = {
        duration: 1,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    };
    animationDef = {
        0: {
            "transform": transformObject
        },
        100: {
            "transform": transformObject1
        }
    };
    animationDefObject = kony.ui.createAnimation(animationDef);
    BBTProductLIST.SegProdList.setAnimations({
        visible: {
            definition: animationDefObject,
            config: animationConfig
        }
    });
}

function ProductpaginationAnimation() {
    var transformObject = kony.ui.makeAffineTransform();
    transformObject.rotate3D(90, 0, 1, 0);
    var animationObject = kony.ui.createAnimation({
        "100": {
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "transform": transformObject
        }
    });
    var animationConfig = {
        "delay": 0.5,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_BACKWARDS,
        "duration": 1
    };

    function callbackConfig() {
        var config = {
            "animationEnd": function() {}
        };
        return config;
    }
    //BBTProductLIST.PrdPage.pagelbl.animate(animationDef, animationConfig);
    BBTProductLIST.PrdPage.pagelbl.animate(animationObject, animationConfig, callbackConfig());
}

function ProductReviewsAnimation() {
    var transformObject = kony.ui.makeAffineTransform();
    transformObject.scale(0, 0);
    var transformObject1 = kony.ui.makeAffineTransform();
    transformObject1.scale(1, 1);
    animationConfig = {
        duration: 1,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    };
    animationDef = {
        0: {
            "transform": transformObject
        },
        100: {
            "transform": transformObject1
        }
    };
    animationDefObject = kony.ui.createAnimation(animationDef);
    BBTProductDetails.ProdReviewsSeg.setAnimations({
        visible: {
            definition: animationDefObject,
            config: animationConfig
        }
    });
}

function onSearchIconClick() {
    BBTCategories.BBTCflexmain.FlexSearchAnimation.isVisible = true;
    BBTCategories.BBTCflexmain.FlexSearchAnimation.opacity = '0.8';
    BBTCategories.BBTCflexmain.FlexSearchAnimation.zIndex = '8';
    var animDefinition = {
        0: {
            "top": "0%"
        },
        100: {
            "top": "10%"
        }
    };
    var animDef = kony.ui.createAnimation(animDefinition);
    var animConfig = {
        "duration": 1.5,
        "iterationCount": 1,
        "delay": 0,
        "direction": kony.anim.DIRECTION_NONE,
        "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    BBTCategories.FlexSearchAnimation.animate(animDef, animConfig, {
        animationStart: searchCallBackStart,
        animationEnd: searchCallBackEnd
    });
    BBTCategories.forceLayout();
}

function searchCallBackStart() {
    //BBTCategories.FlexContainer0be55f47cc25f42.setVisibility(true);
    BBTCategories.forceLayout();
}

function searchCallBackEnd() {
    //do nothing
}

function onCancleClikc() {
    var animDefinition = {
        0: {
            "top": "0%"
        },
        100: {
            "top": "-100%",
            "opacity": 0.0,
            "zIndex": 1,
            "stepConfig": {
                "timingFunction": kony.anim.LINEAR
            }
        }
    };
    var animDef = kony.ui.createAnimation(animDefinition);
    var animConfig = {
        "duration": 1.5,
        "iterationCount": 1,
        "delay": 0,
        "direction": kony.anim.DIRECTION_NONE,
        "fillMode": kony.anim.FILL_MODE_FORWARDS
    };
    BBTCategories.FlexSearchAnimation.animate(animDef, animConfig, {
        animationStart: cancleCallBackStart,
        animationEnd: cancleCallBackEnd
    });
    //BBTCategories.BBTCflexmain.FlexContainer0a95ceb0b8e7a45.opacity='0';
    //BBTCategories.BBTCflexmain.FlexContainer0a95ceb0b8e7a45.zIndex='1';
    //BBTCategories.BBTCflexmain.FlexContainer0a95ceb0b8e7a45.isVisible=false;
    //BBTCategories.forceLayout();
}

function cancleCallBackStart() {
    //do nothing
    BBTCategories.forceLayout();
}

function cancleCallBackEnd() {
    //BBTCategories.FlexContainer0be55f47cc25f42.setVisibility(false);
    BBTCategories.forceLayout();
}

function cancelMethod() {
    var searchbtn = BBTCategories.FlexSearchAnimation.searchBtn.text;
    if (searchbtn == "Cancel") {
        onCancleClikc();
    } else {
        var searchtxt = BBTCategories.FlexSearchAnimation.searchTbox.text;
        if (searchtxt === "") {
            alert("Please enter keywords to get the results");
            return false;
        }
        if (searchtxt !== "") {
            if (!searchtxt.match(/[A-Za-z0-9 ]/)) //+#-.
            {
                alert("Please search for valid keyword");
                BBTCategories.FlexSearchAnimation.searchTbox.text = "";
                return false;
            }
            //return false;
        }
        var pageid = 1;
        searchproducts(pageid);
    }
}